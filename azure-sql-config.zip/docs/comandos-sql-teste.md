# 📑 Comandos SQL de Teste no Azure SQL

Este arquivo contém alguns comandos básicos para testar sua conexão e o funcionamento do banco de dados criado no Azure.

## 🏗️ Criação de Tabela

```sql
CREATE TABLE Clientes (
    ID INT PRIMARY KEY IDENTITY,
    Nome NVARCHAR(100),
    Email NVARCHAR(100)
);
```

## ➕ Inserção de Dados

```sql
INSERT INTO Clientes (Nome, Email)
VALUES ('Leonardo Mendes', 'leonardo@email.com');
```

## 🔍 Consulta de Dados

```sql
SELECT * FROM Clientes;
```

## ✍️ Atualização de Dados

```sql
UPDATE Clientes
SET Email = 'novoemail@email.com'
WHERE Nome = 'Leonardo Mendes';
```

## ❌ Exclusão de Dados

```sql
DELETE FROM Clientes
WHERE Nome = 'Leonardo Mendes';
```

---

## ✅ Observação
- Sempre teste os comandos utilizando o **Query Editor** no Azure ou ferramentas como **SSMS**, **Azure Data Studio** ou **DBeaver**.
- Após testar, é recomendado excluir as tabelas ou os dados criados se não forem mais necessários.

---